// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "device_agent.h"
#include "../logger.h"
#include "json.hpp"

#include <nx/kit/json.h>
#include <nx/sdk/analytics/helpers/event_metadata.h>
#include <nx/sdk/analytics/helpers/event_metadata_packet.h>
#include <nx/sdk/analytics/helpers/object_metadata.h>
#include <nx/sdk/analytics/helpers/object_metadata_packet.h>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/beast/version.hpp>
#include <boost/asio.hpp>
#include <set>

#define NX_DEBUG_ENABLE_OUTPUT true
#include <nx/kit/debug.h>
#include <nx/sdk/helpers/settings_response.h>
#include "device_agent_manifest.h"

#include <sstream>


namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace intrusion_detection {

using namespace nx::sdk;
using namespace nx::sdk::analytics;

using tcp = boost::asio::ip::tcp;
namespace http = boost::beast::http;
using json = nlohmann::json;
namespace net = boost::asio;
namespace beast = boost::beast;
/**
    * @param deviceInfo Various information about the related device, such as its id, vendor, model,
    *     etc.
    */
DeviceAgent::DeviceAgent(const nx::sdk::IDeviceInfo* deviceInfo) :
    // Call the DeviceAgent helper class constructor telling it to verbosely report to stderr.
    ConsumingDeviceAgent(deviceInfo, /*enableOutput*/ true)
{
    
}

DeviceAgent::~DeviceAgent()
{

}





void DeviceAgent::fetchAndLogROI(const std::string& ip, const std::string& bearerToken, const std::string& targetRoiName) {
	Logger::getInstance().log("[INTRUSION DETECTION][SYSTEM] Fetching ROI for model: " + modelType + ", IP: " + ip + ", Target ROI Name: " + targetRoiName);
    if (modelType == "VSB-55") {
        this->fetchAndLogRoiVSB55(ip, bearerToken, targetRoiName);
    }
    else if (modelType == "CPS-100") {
        // For CPS-100, we can implement a similar function if needed.
        // Currently, it does not require fetching ROI from the server.
        this->fetchAndLogRoiCPS100(ip, bearerToken, targetRoiName);
    }
}

void DeviceAgent::fetchAndLogRoiCPS100(const std::string& ip, const std::string& bearerToken, const std::string& targetRoiName) {
    try {
        net::io_context ioc;
        tcp::resolver resolver(ioc);
        beast::tcp_stream stream(ioc);

        // Resolve IP
        auto const results = resolver.resolve(ip, "8080");

        Logger::getInstance().log("[INTRUSION DETECTION][SYSTEM] Connecting to " + ip);
        stream.connect(results);

        // Create GET request
        http::request<http::string_body> req{http::verb::get, "/ainvr/api/rois", 11 };
        req.set(http::field::host, ip);
        req.set(http::field::authorization, "Bearer " + bearerToken);
        req.set(http::field::user_agent, BOOST_BEAST_VERSION_STRING);

        // Send request
        http::write(stream, req);

        // Receive response
        beast::flat_buffer buffer;
        http::response<http::string_body> res;
        http::read(stream, buffer, res);

        // Close connection
        beast::error_code ec;
        stream.socket().shutdown(tcp::socket::shutdown_both, ec);

        // Debug
        // Logger::getInstance().log("[DEBUG] HTTP Status: " + std::to_string(res.result_int()));
        // Logger::getInstance().log("[DEBUG] Response body: " + res.body());

        // Parse response body
        json j = json::parse(res.body());

        for (const auto& roi : j["content"]) {
            if (roi["eventName"] == targetRoiName) {
                const auto& points = roi["region"][0]["contour"];
                roiX1 = (points[0]["x"].get<double>())/3840;
                roiY1 = (points[0]["y"].get<double>())/1920;

                roiX2 = (points[1]["x"].get<double>())/3840;
                roiY2 = (points[1]["y"].get<double>())/1920;

                roiX3 = (points[2]["x"].get<double>())/3840;
                roiY3 = (points[2]["y"].get<double>())/1920;

                roiX4 = (points[3]["x"].get<double>())/3840;
                roiY4 = (points[3]["y"].get<double>())/1920;

                // Logger::getInstance().log("[ROI] roiX1: " + std::to_string(roiX1) + ", roiY1: " + std::to_string(roiY1));
                // Logger::getInstance().log("[ROI] roiX2: " + std::to_string(roiX2) + ", roiY2: " + std::to_string(roiY2));
                // Logger::getInstance().log("[ROI] roiX3: " + std::to_string(roiX3) + ", roiY3: " + std::to_string(roiY3));
                // Logger::getInstance().log("[ROI] roiX4: " + std::to_string(roiX4) + ", roiY4: " + std::to_string(roiY4));

                return;
            }
        }

        Logger::getInstance().log("[WARN] ROI name not found.");
    }
    catch (const std::exception& e) {
        Logger::getInstance().log(std::string("[ERROR] ") + e.what());
    }
}


void DeviceAgent::fetchAndLogRoiVSB55(const std::string& ip, const std::string& bearerToken, const std::string& targetRoiName) {
    try {
        net::io_context ioc;
        tcp::resolver resolver(ioc);
        beast::tcp_stream stream(ioc);

        // Resolve IP
        auto const results = resolver.resolve(ip, "80");
		Logger::getInstance().log("[INTRUSION DETECTION][SYSTEM] Connecting to " + ip);
        stream.connect(results);

        // Create GET request
        http::request<http::string_body> req{ http::verb::get, "/edge/roi", 11 };
        req.set(http::field::host, ip);
        req.set(http::field::authorization, "Bearer " + bearerToken);
        req.set(http::field::user_agent, BOOST_BEAST_VERSION_STRING);

        // Send request
        http::write(stream, req);

        // Receive response
        beast::flat_buffer buffer;
        http::response<http::string_body> res;
        http::read(stream, buffer, res);

        // Close connection
        beast::error_code ec;
        stream.socket().shutdown(tcp::socket::shutdown_both, ec);

        // Parse response body
        json j = json::parse(res.body());

        for (const auto& roi : j["content"]) {
            if (roi["name"] == targetRoiName) {
                const auto& points = roi["roi"];
                roiX1 = points[0]["x"].get<double>();
                roiY1 = points[0]["y"].get<double>();

                roiX2 = points[1]["x"].get<double>();
                roiY2 = points[1]["y"].get<double>();

                roiX3 = points[2]["x"].get<double>();
                roiY3 = points[2]["y"].get<double>();

                roiX4 = points[3]["x"].get<double>();
                roiY4 = points[3]["y"].get<double>();

                Logger::getInstance().log("[ROI] roiX1: " + std::to_string(roiX1) + ", roiY1: " + std::to_string(roiY1));
                Logger::getInstance().log("[ROI] roiX2: " + std::to_string(roiX2) + ", roiY2: " + std::to_string(roiY2));
                Logger::getInstance().log("[ROI] roiX3: " + std::to_string(roiX3) + ", roiY3: " + std::to_string(roiY3));
                Logger::getInstance().log("[ROI] roiX4: " + std::to_string(roiX4) + ", roiY4: " + std::to_string(roiY4));

                return;
            }
        }

        Logger::getInstance().log("[WARN] ROI name not found.");
    }
    catch (const std::exception& e) {
        Logger::getInstance().log(std::string("[ERROR] ") + e.what());
    }
}







/**
    *  @return JSON with the particular structure. Note that it is possible to fill in the values
    * that are not known at compile time, but should not depend on the DeviceAgent settings.
    */
std::string DeviceAgent::manifestString() const
{
    return kDeviceAgentManifest;
}

Result<const ISettingsResponse*> DeviceAgent::settingsReceived()
{
	Logger::getInstance().log("[INTRUSION DETECTION][SYSTEM] Settings received.");
    std::map<std::string, std::string> settings = currentSettings();

    // Get port values from settings and changing it to int
    frameWidth = std::stoi(settings[kStreamingWidthSettings]);
    frameHeight = std::stoi(settings[kStreamingHeightSettings]);


    std::string roiName = settings[kROINameSettings];
    std::string bearerToken = settings[kBearerAuthKey];
    std::string vaidioIP = settings[kVaidioEdgeIPSettings];

    this->fetchAndLogROI(vaidioIP, bearerToken, roiName);


    return nullptr;
}




/**
    * Called when the Server sends a new compressed frame from a camera.
    */
bool DeviceAgent::pushCompressedVideoFrame(const ICompressedVideoPacket* videoFrame)
{
    if (!videoFrame)
    {
        Logger::getInstance().log("[INTRUSION DETECTION][Error] Received null video frame.");
        return false;
    }

    if (videoFrame->width() == 0 || videoFrame->height() == 0)
    {
        Logger::getInstance().log("[INTRUSION DETECTION][Error] Received frame with invalid dimensions.");
        return false;
    }

    ++m_frameIndex;
    int64_t m_lastVideoFrameTimestampUs = videoFrame->timestampUs();
    int m_frameWidth = videoFrame->width();
    int m_frameHeight = videoFrame->height();

    return true; //< There were no errors while processing the video frame.
}

/**
    * Serves the similar purpose as pushMetadataPacket(). The differences are:
    * - pushMetadataPacket() is called by the plugin, while pullMetadataPackets() is called by Server.
    * - pushMetadataPacket() expects one metadata packet, while pullMetadataPacket expects the
    *     std::vector of them.
    *
    * There are no strict rules for deciding which method is "better". A rule of thumb is to use
    * pushMetadataPacket() when you generate one metadata packet and do not want to store it in the
    * class field, and use pullMetadataPackets otherwise.
    */
bool DeviceAgent::pullMetadataPackets(std::vector<IMetadataPacket*>* metadataPackets)
{
    // metadataPackets->push_back(generateObjectMetadataPacket(normX, normY, normW, normH).releasePtr());

    return true; //< There were no errors while filling metadataPackets.
}

void DeviceAgent::doSetNeededMetadataTypes(
    nx::sdk::Result<void>* /*outValue*/,
    const nx::sdk::analytics::IMetadataTypes* /*neededMetadataTypes*/)
{
}

static void addAttributesFromProperty(const nlohmann::json& property, nx::sdk::Ptr<nx::sdk::analytics::ObjectMetadata> objectMetadata)
{
    for (auto it = property.begin(); it != property.end(); ++it)
    {
        const std::string& key = it.key();
        const auto& value = it.value();

        if (value.is_string())
        {
            objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, value.get<std::string>()));
        }
        else if (value.is_number())
        {
            objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, std::to_string(value.get<double>())));
        }
        else if (value.is_boolean())
        {
            objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, value.get<bool>() ? "true" : "false"));
        }
        else if (value.is_array())
        {
            for (const auto& item : value)
            {
                if (item.is_string())
                    objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, item.get<std::string>()));
                else if (item.is_number())
                    objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, std::to_string(item.get<double>())));
                else if (item.is_boolean())
                    objectMetadata->addAttribute(nx::sdk::makePtr<nx::sdk::Attribute>(key, item.get<bool>() ? "true" : "false"));
            }
        }
    }
}


Ptr<IMetadataPacket> DeviceAgent::generateObjectMetadataPacket(const std::vector<std::tuple<std::string, float, float, float, float, float, nlohmann::json>>& objects, int64_t timestamp)
{
    // ObjectMetadataPacket contains arbitrary number of ObjectMetadata.
    // setTimestampUs sets object timestamp in a specific form.
    // setDurationUs sets duration of rectangle in microseconds(10^-6)
    // setBoundingBox sets how the rect besides object should be - normalize!
    auto packet = makePtr<ObjectMetadataPacket>();
    int64_t timestampUs = timestamp * 1000;
    packet->setTimestampUs(timestampUs);
    packet->setDurationUs(1000000);

    for (const auto& [objectType, x, y, w, h, confidence, attributes] : objects) {
        auto objectMetadata = makePtr<ObjectMetadata>();

        float norm_x = x;
        float norm_y = y;
        float norm_w = w;
        float norm_h = h;

        // Logger::getInstance().log(std::to_string(frameWidth));
        // Logger::getInstance().log(std::to_string(frameHeight));

        // float streamFrameWidth = frameWidth;
        // float streamFrameHeight = frameHeight;

        if (x > 1 || y > 1 || w > 1 || h > 1)
        {
			norm_x = x / frameWidth;
			norm_y = y / frameHeight;
			norm_w = w / frameWidth;
			norm_h = h / frameHeight;
        }

        


        Logger::getInstance().log(
            "[INTRUSION DETECTION][Object] Type: " + objectType +
            ", x: " + std::to_string(norm_x) +
            ", y: " + std::to_string(norm_y) +
            ", w: " + std::to_string(norm_w) +
            ", h: " + std::to_string(norm_h) +
			", confidence: " + std::to_string(confidence));


        // Change Object Type to corresponding ID
        auto it = kCategoryToObjectTypeId.find(objectType);
        std::string objectTypeId = it->second;

        objectMetadata->setTypeId(objectTypeId);
        nx::sdk::Uuid m_trackId = nx::sdk::UuidHelper::randomUuid();


        // Filtered JSON
        nlohmann::json filtered;        
        std::set<std::string> keysToKeep = { "colors" };
        for (auto& [key, value] : attributes.items()) {
            if (keysToKeep.count(key)) {
                filtered[key] = value;
            }
        }

        // Output the result
		Logger::getInstance().log("[INTRUSION DETECTION][Attributes] Filtered attributes: " + filtered.dump());

        addAttributesFromProperty(filtered, objectMetadata);

        objectMetadata->setTrackId(m_trackId);
        objectMetadata->setBoundingBox(Rect(norm_x, norm_y, norm_w, norm_h));
        objectMetadata->setConfidence(confidence);


        packet->addItem(objectMetadata.get());
    }

    return packet;
}



void DeviceAgent::publishPacket(nx::sdk::analytics::IMetadataPacket* packet)
{
    pushMetadataPacket(packet);
}



//-------------------------------------------------------------------------------------------------
// private

Ptr<IMetadataPacket> DeviceAgent::generateEventMetadataPacket()
{
    // EventMetadataPacket contains arbitrary number of EventMetadata.
    const auto eventMetadataPacket = makePtr<EventMetadataPacket>();
    eventMetadataPacket->setTimestampUs(m_lastVideoFrameTimestampUs);
    eventMetadataPacket->setDurationUs(100000);

    const auto eventMetadata = makePtr<EventMetadata>();
    eventMetadata->setTypeId("ironyun.stub.event");
    eventMetadata->setIsActive(true);
    eventMetadata->setCaption("Intrusion Detected");
    eventMetadata->setDescription("New track #" + std::to_string(m_trackIndex) + " started");
    eventMetadataPacket->addItem(eventMetadata.get());


    // Generate index and track id for the next track.
    ++m_trackIndex;
    m_trackId = nx::sdk::UuidHelper::randomUuid();

    return eventMetadataPacket;
}



void DeviceAgent::getPluginSideSettings(
    Result<const ISettingsResponse*>* outResult) const
{
    const auto response = new SettingsResponse();

    nx::kit::Json::array jsonPoints{
        nx::kit::Json::array{roiX1, roiY1},
        nx::kit::Json::array{roiX2, roiY2},
        nx::kit::Json::array{roiX3, roiY3},
        nx::kit::Json::array{roiX4, roiY4}
    };

    nx::kit::Json::object jsonFigure;
    jsonFigure.insert(std::make_pair("points", jsonPoints));

    nx::kit::Json::object jsonResult;
    jsonResult.insert(std::make_pair("figure", jsonFigure));

    response->setValue("testPolygon", nx::kit::Json(jsonResult).dump());
    *outResult = response;
}





} // namespace intrusion_detection
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
