// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#pragma once

#include <nx/sdk/analytics/helpers/consuming_device_agent.h>
#include <nx/sdk/helpers/uuid_helper.h>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/asio.hpp>
#include "json.hpp"

#include <nx/sdk/analytics/i_device_agent.h>


#include "engine.h"
#include "iostream"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace intrusion_detection {

using tcp = boost::asio::ip::tcp;

const std::string kStreamingWidthSettings =
"streamingWidth";
const std::string kStreamingHeightSettings =
"streamingHeight";


class DeviceAgent : public nx::sdk::analytics::ConsumingDeviceAgent
{
public:
    DeviceAgent(const nx::sdk::IDeviceInfo* deviceInfo);
    virtual ~DeviceAgent() override;

    int frameWidth;
    int frameHeight;

    float roiX1 = 0.2f;
    float roiX2 = 0.7f;
    float roiX3 = 0.7f;
    float roiX4 = 0.2f;
    float roiY1 = 0.2f;
    float roiY2 = 0.2f;
    float roiY3 = 0.7f;
    float roiY4 = 0.7f;




protected:
    virtual std::string manifestString() const override;

    virtual nx::sdk::Result<const nx::sdk::ISettingsResponse*> settingsReceived() override;

    virtual bool pushCompressedVideoFrame(
        const nx::sdk::analytics::ICompressedVideoPacket* videoFrame) override;

    virtual bool pullMetadataPackets(
        std::vector<nx::sdk::analytics::IMetadataPacket*>* metadataPackets) override;

    virtual void doSetNeededMetadataTypes(
        nx::sdk::Result<void>* outValue,
        const nx::sdk::analytics::IMetadataTypes* neededMetadataTypes) override;

    void fetchAndLogROI(const std::string& ip, const std::string& bearerToken, const std::string& targetRoiName);
    void fetchAndLogRoiVSB55(const std::string&, const std::string&, const std::string&);
    void fetchAndLogRoiCPS100(const std::string&, const std::string&, const std::string&);


public:
    nx::sdk::Ptr<nx::sdk::analytics::IMetadataPacket> generateEventMetadataPacket();
    nx::sdk::Ptr<nx::sdk::analytics::IMetadataPacket> generateObjectMetadataPacket(const std::vector<std::tuple<std::string, float, float, float, float, float, nlohmann::json>>& objects, int64_t  timestamp);

    void publishPacket(nx::sdk::analytics::IMetadataPacket* packet);

    // Map from raw type (category) to full objectTypeId
    static inline const std::unordered_map<std::string, std::string> kCategoryToObjectTypeId = {
        {"vehicle", "ironyun.vehicle.object"},
        {"bicycle", "ironyun.bicycle.object"},
        {"bus", "ironyun.bus.object"},
        {"car", "ironyun.car.object"},
        {"forklift", "ironyun.forklift.object"},
        {"jeepney", "ironyun.jeepney.object"},
        {"motorcycle", "ironyun.motorcycle.object"},
        {"tricycle", "ironyun.tricycle.object"},
        {"truck", "ironyun.truck.object"},
        {"tuktuk", "ironyun.tuktuk.object"},

        {"head", "ironyun.head.object"},
        {"person", "ironyun.person.object"},

        {"bird", "ironyun.bird.object"},
        {"cat", "ironyun.cat.object"},
        {"cow", "ironyun.cow.object"},
        {"dog", "ironyun.dog.object"},
        {"horse", "ironyun.horse.object"},
        {"wild_animal", "ironyun.wild_animal.object"},

        {"backpack", "ironyun.backpack.object"},
        {"bag", "ironyun.bag.object"},
        {"cell_phone", "ironyun.cell_phone.object"},
        {"luggage", "ironyun.luggage.object"},
        {"stroller", "ironyun.stroller.object"},
        {"umbrella", "ironyun.umbrella.object"},
        {"wheelchair", "ironyun.wheelchair.object"},

        {"fire", "ironyun.fire.object"},
        {"handgun", "ironyun.handgun.object"},
        {"rifle", "ironyun.rifle.object"},
        {"smoke", "ironyun.smoke.object"}
    };


    std::string modelType;

    /** Lenght of the the track (in frames). The value was chosen arbitrarily. */
    static constexpr int kTrackFrameCount = 256;

private:
    nx::sdk::Uuid m_trackId = nx::sdk::UuidHelper::randomUuid();
    int m_frameIndex = 0; /**< Used for generating the detection in the right place. */
    int m_trackIndex = 0; /**< Used in the description of the events. */

    /** Used for binding object and event metadata to the particular video frame. */
    int64_t m_lastVideoFrameTimestampUs = 0;
    float m_frameWidth;
    float m_frameHeight;

    virtual void getPluginSideSettings(
        nx::sdk::Result<const nx::sdk::ISettingsResponse*>* outResult) const override;
};

} // namespace intrusion_detection
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
