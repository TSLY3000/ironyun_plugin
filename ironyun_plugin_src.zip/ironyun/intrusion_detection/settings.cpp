// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "settings.h"

namespace nx::vms_server_plugins::analytics::ironyun::intrusion_detection {


	extern const std::string kHttpUrlVar = "httpUrl";

} // namespace nx::vms_server_plugins::analytics::ironyun::intrusion_detection 
