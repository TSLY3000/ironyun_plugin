#pragma once
#include <string>
#include "device_agent.h"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace intrusion_detection {



static const std::string kDeviceAgentManifest = R"json(
{
    "supportedTypes": [
    { "objectTypeId": "ironyun.vehicle.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.bicycle.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.bus.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.car.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.forklift.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.jeepney.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.motorcycle.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.tricycle.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.truck.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.tuktuk.object", "attributes": [ "Color" ] },

    { "objectTypeId": "ironyun.head.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.person.object", "attributes": [ "Color" ] },

    { "objectTypeId": "ironyun.bird.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.cat.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.cow.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.dog.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.horse.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.wild_animal.object", "attributes": [ "Color" ] },

    { "objectTypeId": "ironyun.backpack.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.bag.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.cell_phone.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.luggage.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.stroller.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.umbrella.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.wheelchair.object", "attributes": [ "Color" ] },

    { "objectTypeId": "ironyun.fire.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.handgun.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.rifle.object", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.smoke.object", "attributes": [ "Color" ] }

    ],

    "typeLibrary":{ 
    "eventTypes": [
        {
            "id": "ironyun.stub.event",
            "name": "Stub"
        }
    ],

    "objectTypes": [
        { "id": "ironyun.vehicle.object",      "name": "Vehicle" },
        { "id": "ironyun.bicycle.object",      "name": "Bicycle" },
        { "id": "ironyun.bus.object",          "name": "Bus" },
        { "id": "ironyun.car.object",          "name": "Car" },
        { "id": "ironyun.forklift.object",     "name": "Forklift" },
        { "id": "ironyun.jeepney.object",      "name": "Jeepney" },
        { "id": "ironyun.motorcycle.object",   "name": "Motorcycle" },
        { "id": "ironyun.tricycle.object",     "name": "Tricycle" },
        { "id": "ironyun.truck.object",        "name": "Truck" },
        { "id": "ironyun.tuktuk.object",       "name": "Tuktuk" },

        { "id": "ironyun.head.object",         "name": "Head" },
        { "id": "ironyun.person.object",       "name": "Person" },

        { "id": "ironyun.bird.object",         "name": "Bird" },
        { "id": "ironyun.cat.object",          "name": "Cat" },
        { "id": "ironyun.cow.object",          "name": "Cow" },
        { "id": "ironyun.dog.object",          "name": "Dog" },
        { "id": "ironyun.horse.object",        "name": "Horse" },
        { "id": "ironyun.wild_animal.object",  "name": "Wild Animal" },

        { "id": "ironyun.backpack.object",     "name": "Backpack" },
        { "id": "ironyun.bag.object",          "name": "Bag" },
        { "id": "ironyun.cell_phone.object",   "name": "Cell Phone" },
        { "id": "ironyun.luggage.object",      "name": "Luggage" },
        { "id": "ironyun.stroller.object",     "name": "Stroller" },
        { "id": "ironyun.umbrella.object",     "name": "Umbrella" },
        { "id": "ironyun.wheelchair.object",   "name": "Wheelchair" },

        { "id": "ironyun.fire.object",         "name": "Fire" },
        { "id": "ironyun.handgun.object",      "name": "Handgun" },
        { "id": "ironyun.rifle.object",        "name": "Rifle" },
        { "id": "ironyun.smoke.object",        "name": "Smoke" }
    ]
    }

}
)json";



} // namespace facial_recognition
} // namespace stub
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
