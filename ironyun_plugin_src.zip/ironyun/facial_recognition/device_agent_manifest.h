#pragma once
#include <string>
#include "device_agent.h"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace facial_recognition {



static const std::string kDeviceAgentManifest = R"json(
{
    "supportedTypes": [
    { "objectTypeId": "ironyun.staff.staff", "attributes": [ "Color" ] },
    { "objectTypeId": "ironyun.notin.list", "attributes": [ "Color" ] }
    ],

    "typeLibrary":{ 
    "eventTypes": [
        {
            "id": "ironyun.stub.event",
            "name": "Stub"
        }
    ],

    "objectTypes": [
        { "id": "ironyun.staff.staff",   "name": "staff" },
        { "id": "ironyun.notin.list",    "name": "Not in list" }
    ]
    }

}
)json";



} // namespace facial_recognition
} // namespace stub
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
