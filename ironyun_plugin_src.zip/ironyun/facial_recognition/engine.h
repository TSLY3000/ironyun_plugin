// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#pragma once

#include <nx/sdk/analytics/helpers/engine.h>
#include <nx/sdk/analytics/helpers/plugin.h>
#include <nx/sdk/analytics/i_compressed_video_packet.h>
#include <unordered_map>


#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/asio.hpp>



namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace facial_recognition {

    const std::string kHttpServerPortSettings =
        "HttpServerPort";
    const std::string kModelTypeSettings =
        "ironYunModelGroup";

    class DeviceAgent;

    class Engine : public nx::sdk::analytics::Engine
    {
    public:
        Engine();
        virtual ~Engine() override;



    protected:
        virtual std::string manifestString() const override;

        virtual nx::sdk::Result<const nx::sdk::ISettingsResponse*> settingsReceived() override;

    protected:
        virtual void doObtainDeviceAgent(
            nx::sdk::Result<nx::sdk::analytics::IDeviceAgent*>* outResult,
            const nx::sdk::IDeviceInfo* deviceInfo) override;

    private:
        DeviceAgent* getDeviceAgent(const std::string& cameraId);
        void handleSession(boost::asio::ip::tcp::socket socket, const std::string& modelType);
        void handleSessionCPS100(boost::asio::ip::tcp::socket socket);
        void handleSessionVSB55(boost::asio::ip::tcp::socket socket);
        void startServer(int port, std::string modelType);
        void stopServer();


    private:
        // Thread control
        std::atomic<bool> m_serverRunning = false;
        std::mutex m_serverMutex;

        std::optional<boost::asio::io_context> m_ioContext;
        std::optional<boost::asio::ip::tcp::acceptor> m_acceptor;
        std::thread m_serverThread;
        std::atomic<bool> m_running = false;

        std::unordered_map<std::string, DeviceAgent*> m_deviceAgents;


        // Settings
        bool initialized = false;
        int portSettings;
        std::string modelTypeSettings;


    }; // class Engine

} // namespace facial_recognition
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
