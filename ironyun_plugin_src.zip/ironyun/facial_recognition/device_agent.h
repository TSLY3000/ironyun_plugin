// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#pragma once

#include <nx/sdk/analytics/helpers/consuming_device_agent.h>
#include <nx/sdk/helpers/uuid_helper.h>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/asio.hpp>
#include "json.hpp"

#include <nx/sdk/analytics/i_device_agent.h>


#include "engine.h"
#include "iostream"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace facial_recognition {

using tcp = boost::asio::ip::tcp;

const std::string kStreamingWidthSettings =
"streamingWidth";
const std::string kStreamingHeightSettings =
"streamingHeight";


class DeviceAgent : public nx::sdk::analytics::ConsumingDeviceAgent
{
public:
    DeviceAgent(const nx::sdk::IDeviceInfo* deviceInfo);
    virtual ~DeviceAgent() override;

    int frameWidth;
    int frameHeight;

protected:
    virtual std::string manifestString() const override;

    virtual nx::sdk::Result<const nx::sdk::ISettingsResponse*> settingsReceived() override;

    virtual bool pushCompressedVideoFrame(
        const nx::sdk::analytics::ICompressedVideoPacket* videoFrame) override;

    virtual bool pullMetadataPackets(
        std::vector<nx::sdk::analytics::IMetadataPacket*>* metadataPackets) override;

    virtual void doSetNeededMetadataTypes(
        nx::sdk::Result<void>* outValue,
        const nx::sdk::analytics::IMetadataTypes* neededMetadataTypes) override;

public:
    nx::sdk::Ptr<nx::sdk::analytics::IMetadataPacket> generateEventMetadataPacket();
    nx::sdk::Ptr<nx::sdk::analytics::IMetadataPacket> generateObjectMetadataPacket(const std::vector<std::tuple<std::string, float, float, float, float, float, nlohmann::json>>& objects, int64_t  timestamp);

    void publishPacket(nx::sdk::analytics::IMetadataPacket* packet);

    // Map from raw type (category) to full objectTypeId
    static inline const std::unordered_map<std::string, std::string> kCategoryToObjectTypeId = {
        {"staff", "ironyun.staff.staff"},
        {"Not in list", "ironyun.notin.list"}
    };



    /** Lenght of the the track (in frames). The value was chosen arbitrarily. */
    static constexpr int kTrackFrameCount = 256;

private:
    nx::sdk::Uuid m_trackId = nx::sdk::UuidHelper::randomUuid();
    int m_frameIndex = 0; /**< Used for generating the detection in the right place. */
    int m_trackIndex = 0; /**< Used in the description of the events. */

    /** Used for binding object and event metadata to the particular video frame. */
    int64_t m_lastVideoFrameTimestampUs = 0;
    float m_frameWidth;
    float m_frameHeight;

    virtual void getPluginSideSettings(
        nx::sdk::Result<const nx::sdk::ISettingsResponse*>* outResult) const override;
};

} // namespace facial_recognition
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
