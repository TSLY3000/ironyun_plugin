// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "plugin.h"
#include "engine.h"
#include <iostream>
#include "settings.h"
#include "../logger.h"

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace object_detection {


using namespace nx::sdk;
using namespace nx::sdk::analytics;

Result<IEngine*> Plugin::doObtainEngine()
{
    return new Engine();
}

    /**
        * JSON with the particular structure. Note that it is possible to fill in the values that are not
        * known at compile time.
        *
        * - id: Unique identifier for a plugin with format "{vendor_id}.{plugin_id}", where
        *     {vendor_id} is the unique identifier of the plugin creator (person or company name) and
        *     {plugin_id} is the unique (for a specific vendor) identifier of the plugin.
        * - name: A human-readable short name of the plugin (displayed in the "Camera Settings" window
        *     of the Client).
        * - description: Description of the plugin in a few sentences.
        * - version: Version of the plugin.
        * - vendor: Plugin creator (person or company) name.
        */
std::string Plugin::manifestString() const
{
    return /*suppress newline*/ 1 + (const char*)R"json(
    {
    "id": "iy.object.detection",
    "name": "IronYun Object Detection",
    "description": "Integrates IronYun's AI-powered object detection algorithm with Nx Witness. This plugin receives real-time event data from IronYun's backend and overlays object alerts directly on the video stream, enabling accurate, responsive, and efficient perimeter protection within the Nx environment.",
    "version": "1.2.0",
    "vendor": "ASPEED",

    "engineSettingsModel":
        {
            "type": "Settings",
            "items":
            [
                {
                    "type": "GroupBox",
                    "caption": "API Connection",
                    "items":
                    [
                        {
                            "type": "TextField",
                            "name": ")json" + kHttpServerPortSettings + R"json(",
                            "caption": "Http Port",
                            "defaultValue": "4995"
                        }
                    ]
                },
                {
                    "type": "GroupBox",
                    "caption": "Model Selection",
                    "items":
                    [
                        {
                            "type": "RadioButtonGroup",
                            "name": ")json" + kModelTypeSettings + R"json(",
                            "caption": "Model: ",
                            "description": "Choose Ironyun Model Used",
                            "defaultValue": "CPS-100",
                            "range":
                                [
                                    "CPS-100",
                                    "VSB-55"
                                ]
                        }
                    ]
                }
            ]
        }
    
    }
    )json";
}



} // namespace object_detection
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
