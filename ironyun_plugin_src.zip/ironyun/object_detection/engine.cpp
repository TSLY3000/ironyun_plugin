// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include "engine.h"
#include "device_agent.h"

#include <thread>
#include <chrono>
#include <iostream>
#include <boost/beast/core.hpp>
#include <boost/beast/http.hpp>
#include <boost/asio.hpp>
#include "json.hpp"
#include <regex>
#include <string>
#include <nx/vms_server_plugins/analytics/ironyun/logger.h>

namespace nx {
namespace vms_server_plugins {
namespace analytics {
namespace ironyun {
namespace object_detection {

using namespace nx::sdk;
using namespace nx::sdk::analytics;

using tcp = boost::asio::ip::tcp;
namespace http = boost::beast::http;
using json = nlohmann::json;



Engine::Engine():
    // Call the DeviceAgent helper class constructor telling it to verbosely report to stderr.
    nx::sdk::analytics::Engine(/*enableOutput*/ true)
{

}

Engine::~Engine()
{
    stopServer();
}

/**
 * Called when the Server opens a video-connection to the camera if the plugin is enabled for this
 * camera.
 *
 * @param outResult The pointer to the structure which needs to be filled with the resulting value
 *     or the error information.
 * @param deviceInfo Contains various information about the related device such as its id, vendor,
 *     model, etc.
 */
void Engine::doObtainDeviceAgent(Result<IDeviceAgent*>* outResult, const IDeviceInfo* deviceInfo)
{
    auto* agent = new DeviceAgent(deviceInfo);
    std::string cameraId = std::string(deviceInfo->id());

    // Map camera ID to the device agent instance
    cameraId.erase(std::remove(cameraId.begin(), cameraId.end(), '{'), cameraId.end());
    cameraId.erase(std::remove(cameraId.begin(), cameraId.end(), '}'), cameraId.end());
    m_deviceAgents[cameraId] = agent;


    // LOGGING DEVICE AGENT
    std::unordered_map<std::string, DeviceAgent*> map = m_deviceAgents;

    for (const auto& [cameraId, agentPtr] : m_deviceAgents) {
        Logger::getInstance().log("[OBJECT DETECTION][DEBUG] cameraId: " + cameraId +
            ", DeviceAgent ptr: " + std::to_string(reinterpret_cast<std::uintptr_t>(agentPtr)));
    }


    *outResult = agent;
}

/**
 * @return JSON with the particular structure. Note that it is possible to fill in the values
 *     that are not known at compile time, but should not depend on the Engine settings.
 */
std::string Engine::manifestString() const
{
    return 1 + (const char*)R"json(
{
    "id": "iy.object.detection",
    "name": "IronYun Object Detection",
    "description": "Integrates IronYun's AI-powered object detection algorithm with Nx Witness. This plugin receives real-time event data from IronYun's backend and overlays object alerts directly on the video stream, enabling accurate, responsive, and efficient perimeter protection within the Nx environment.",
    "version": "1.2.0",
    "vendor": "ASPEED",

    "deviceAgentSettingsModel": {
            "type": "Settings",
            "items":
            [
                {
                    "type": "GroupBox",
                    "caption": "Dimensions",
                    "items":
                    [
                        {
                            "type": "SpinBox",
                            "name": ")json" + kStreamingWidthSettings + R"json(",
                            "caption": "Width",
                            "defaultValue": 3840
                        },
                        {
                            "type": "SpinBox",
                            "name": ")json" + kStreamingHeightSettings + R"json(",
                            "caption": "Height",
                            "defaultValue": 1920
                        }   
                    ]
                }
            ]
        } 
}
)json";
}

Result<const ISettingsResponse*> Engine::settingsReceived()
{
    std::map<std::string, std::string> settings = currentSettings();

    // Get port values from settings and changing it to int
    std::string portString = settings[kHttpServerPortSettings];
    std::string modelType = settings[kModelTypeSettings];


    int port = std::stoi(portString);

    std::string logMessage;
    if (!initialized)
    {
        logMessage = "[OBJECT DETECTION][SYSTEM] Engine initialized with port: " + portString + " and model type: " + modelType;
        Logger::getInstance().log(logMessage);
        initialized = true;
        portSettings = port;
        modelTypeSettings = modelType;
    }
    else
        if (port != portSettings)
        {
            logMessage = "[OBJECT DETECTION][SYSTEM] Engine settings updated to port: " + portString;
            Logger::getInstance().log(logMessage);
            portSettings = port;
        }
    if (modelType != modelTypeSettings)
    {
        logMessage = "[OBJECT DETECTION][SYSTEM] Engine settings updated to model: " + modelType;
        Logger::getInstance().log(logMessage);
        modelTypeSettings = modelType;
    }

    startServer(portSettings, modelType);

    return nullptr;
}

/**
 * Helper function that receives cameraID and returns corresponding pointer to a deviceAgent instance.
 */
DeviceAgent* Engine::getDeviceAgent(const std::string& cameraId)
{
    auto it = m_deviceAgents.find(cameraId);
    if (it != m_deviceAgents.end())
        return it->second;
    return nullptr;
}

// Http Session handling for user to be able to receive data
void Engine::handleSession(tcp::socket socket, const std::string& modelType)
{
    if (modelType == "CPS-100")
    {
        Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] Starting session for CPS-100 model.");
        this->handleSessionCPS100(std::move(socket));
    }
    else if (modelType == "VSB-55")
    {
        Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] Starting session for VSB-55 model.");
        this->handleSessionVSB55(std::move(socket));
    }

}

void Engine::handleSessionVSB55(tcp::socket socket)
{
    try {
        boost::beast::flat_buffer buffer;
        http::request<http::string_body> req;
        http::read(socket, buffer, req);

        http::response<http::string_body> res{
            http::status::ok, req.version()
        };
        res.set(http::field::server, "Boost.Beast");
        res.set(http::field::content_type, "application/json");
        res.keep_alive(req.keep_alive());

        if (req.method() == http::verb::post) {
            Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] Received POST request");

            try {
                std::string raw = req.body();

                // Logger::getInstance().log(raw);

                std::regex uuidRegex(R"("cameraId"\s*:\s*([a-f0-9\-]+))", std::regex_constants::icase);
                raw = std::regex_replace(raw, uuidRegex, R"("cameraId": "$1")");

                json j = json::parse(raw);


                // Getting Camera ID and finding corresponding device_agent
                std::string cameraId = j.value("cameraId", "");
                DeviceAgent* agent = this->getDeviceAgent(cameraId);

                // Device Agent Debugging
                if (!agent)
                {
                    Logger::getInstance().log("[OBJECT DETECTION][ERROR] No DeviceAgent found for cameraId = " + cameraId);
                    res.result(http::status::bad_request);
                    res.body() = R"({"error": "Invalid cameraId"})";
                    return;
                }


                // Extract fields from JSON info from REQUEST
                const auto& metadata = j["metadata"];
                std::string imagePath = metadata.value("image", "");
                int imageWidth = metadata.value("imageWidth", -1);
                int imageHeight = metadata.value("imageHeight", -1);

                std::vector<std::tuple<std::string, float, float, float, float, float, nlohmann::json>> objects;

                for (const auto& obj : metadata["objects"]) {
                    std::string objectType = obj.value("type", "");
                    float x = obj.value("x", -1.0f);
                    float y = obj.value("y", -1.0f);
                    float w = obj.value("w", -1.0f);
                    float h = obj.value("h", -1.0f);
                    float confidence = obj.value("confidence", 0.0f);
                    json attributes = obj.value("property", json::object());
                    objects.emplace_back(objectType, x, y, w, h, confidence, attributes);


                    // Log extracted info
                    
                    Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] type: " + objectType +
                        ", x: " + std::to_string(x) +
                        ", y: " + std::to_string(y) +
                        ", w: " + std::to_string(w) +
                        ", h: " + std::to_string(h) +
                        ", confidence: " + std::to_string(confidence));
                }



                int64_t datetime_ms = j.value("datetime", 0LL);
                int64_t datetime_Us = datetime_ms * 1000;


                // Logger::getInstance().log(std::to_string(datetime_iy));


                auto objectMetadataPacket = agent->generateObjectMetadataPacket(objects, datetime_Us);
                agent->publishPacket(objectMetadataPacket.releasePtr());
                Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Object created and pushed.");
                // Logger::getInstance().log("[OBJECT DETECTION][ENGINE] JSON request fully parsed.");


                res.result(http::status::accepted);
                res.body() = R"({"status": "received"})";
            }
            catch (const std::exception& e) {
                res.result(http::status::bad_request);
                res.body() = std::string(R"({"error": "Invalid JSON", "details": ")") + e.what() + "\"}";
            }
        }
        else {
            res.result(http::status::bad_request);
            res.body() = R"({"error": "Only POST allowed"})";
        }

        res.prepare_payload();
        http::write(socket, res);
    }

    catch (std::exception& e) {
        std::cerr << "Session error: " << e.what() << std::endl;
    }
}

void Engine::handleSessionCPS100(tcp::socket socket)
{
    try {
        boost::beast::flat_buffer buffer;
        http::request<http::string_body> req;
        http::read(socket, buffer, req);

        http::response<http::string_body> res{
            http::status::ok, req.version()
        };
        res.set(http::field::server, "Boost.Beast");
        res.set(http::field::content_type, "application/json");
        res.keep_alive(req.keep_alive());

        if (req.method() == http::verb::post) {
            Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] Received POST request");

            try {
                std::string raw = req.body();

                // Logger::getInstance().log(raw);

                std::regex uuidRegex(R"("cameraId"\s*:\s*([a-f0-9\-]+))", std::regex_constants::icase);
                raw = std::regex_replace(raw, uuidRegex, R"("cameraId": "$1")");

                json j = json::parse(raw);


                // Getting Camera ID and finding corresponding device_agent
                std::string cameraId = j.value("cameraId", "");
                DeviceAgent* agent = this->getDeviceAgent(cameraId);

                // Device Agent Debugging
                if (!agent)
                {
                    Logger::getInstance().log("[OBJECT DETECTION][ERROR] No DeviceAgent found for cameraId = " + cameraId);
                    res.result(http::status::bad_request);
                    res.body() = R"({"error": "Invalid cameraId"})";
                    return;
                }


                // Extract fields from JSON info from REQUEST
                const auto& metadataArray = j["alertObjects"];

                std::vector<std::tuple<std::string, float, float, float, float, float, nlohmann::json>> objects;

                for (const auto& obj : metadataArray) {
                    std::string objectType = obj.value("objectType", "");
                    float x = (obj.value("x", -1.0f));
                    float y = (obj.value("y", -1.0f));
                    float w = (obj.value("w", -1.0f));
                    float h = (obj.value("h", -1.0f));
                    float confidence = obj.value("confidence", 0.0f);
					json attributes = obj.value("metadata", json::object());
                    objects.emplace_back(objectType, x, y, w, h, confidence, attributes);


                    // Log extracted info
                   
                    Logger::getInstance().log("[OBJECT DETECTION][SYSTEM] type: " + objectType +
                        ", x: " + std::to_string(x) +
                        ", y: " + std::to_string(y) +
                        ", w: " + std::to_string(w) +
                        ", h: " + std::to_string(h) +
                        ", confidence: " + std::to_string(confidence));
                }


                // Temporary Fix because of time delay
                int64_t datetime_MS = j["sceneDetail"].value("datetime", 0LL) - 300;

                

                // Logger::getInstance().log(std::to_string(datetime_iy));


                auto objectMetadataPacket = agent->generateObjectMetadataPacket(objects, datetime_MS);
                agent->publishPacket(objectMetadataPacket.releasePtr());
                Logger::getInstance().log("[OBJECT DETECTION][ENGINE] Object created and pushed.");

                // Logger::getInstance().log("[OBJECT DETECTION][ENGINE] JSON request fully parsed.");


                res.result(http::status::accepted);
                res.body() = R"({"status": "received"})";
            }
            catch (const std::exception& e) {
                res.result(http::status::bad_request);
                res.body() = std::string(R"({"error": "Invalid JSON", "details": ")") + e.what() + R"("})";
            }
        }
        else {
            res.result(http::status::bad_request);
            res.body() = R"({"error": "Only POST allowed"})";
        }

        res.prepare_payload();
        http::write(socket, res);
    }

    catch (std::exception& e) {
        std::cerr << "Session error: " << e.what() << std::endl;
    }
}


// Start hosting an http server
void Engine::startServer(int port, std::string modelType)
{
    stopServer(); // Always clean up the previous one

    // Set up fresh context
    m_ioContext.emplace();
    m_acceptor.emplace(*m_ioContext, boost::asio::ip::tcp::endpoint{ boost::asio::ip::tcp::v4(), static_cast<unsigned short>(port) });

    m_running = true;

    m_serverThread = std::thread([this, port, modelType]() {
        // Logger::getInstance().log("[SERVER] Server started on http://localhost:" + std::to_string(port) + " using " + modelType);

        try {
            while (m_running)
            {
                // Logger::getInstance().log("[DEBUG] Waiting for new connection...");

                boost::asio::ip::tcp::socket socket{ *m_ioContext };
                m_acceptor->accept(socket);
                // Logger::getInstance().log("[DEBUG] Connection accepted.");

                std::thread([this, modelType](boost::asio::ip::tcp::socket socket) mutable {
                    this->handleSession(std::move(socket), modelType);
                    }, std::move(socket)).detach();
            }
        }
        catch (const std::exception& e)
        {
            Logger::getInstance().log(std::string("Fatal server error: ") + e.what());
        }
        });
}


// Destroys server if main Nx server stops
void Engine::stopServer() {
    // Logger::getInstance().log("[DEBUG] stopServer() CALLED");
    // Logger::getInstance().log(std::to_string(m_running));


    if (m_running)
    {
        // Logger::getInstance().log("[OBJECT DETECTION][SERVER] Stopping server...");


        if (m_acceptor)
        {
            boost::system::error_code ec;
            m_acceptor->close(ec);
            if (ec)
                Logger::getInstance().log("Failed to close acceptor: " + ec.message());
        }

        if (m_ioContext)
            m_ioContext->stop();

        if (m_serverThread.joinable())
            m_serverThread.join();

        m_running = false;
    }
}



} // namespace facial_recognition
} // namespace ironyun
} // namespace analytics
} // namespace vms_server_plugins
} // namespace nx
