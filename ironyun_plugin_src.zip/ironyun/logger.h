// logger.h
#pragma once
#include <string>
#include <fstream>
#include <mutex>

class Logger {
public:
    static Logger& getInstance();
    void log(const std::string& message);

private:
    Logger();                          // private constructor
    ~Logger();                         // private destructor
    Logger(const Logger&) = delete;   // prevent copying
    Logger& operator=(const Logger&) = delete;

    std::ofstream logFile_;
    std::mutex logMutex_;
};
