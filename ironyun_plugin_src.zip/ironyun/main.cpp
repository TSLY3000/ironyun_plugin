// Copyright 2018-present Network Optix, Inc. Licensed under MPL 2.0: www.mozilla.org/MPL/2.0/

#include <nx/kit/debug.h>

#include "object_detection/plugin.h"
#include "facial_recognition/plugin.h"
#include "intrusion_detection/plugin.h"

extern "C" NX_PLUGIN_API nx::sdk::IPlugin* createNxPluginByIndex(int instanceIndex)
{
    using namespace nx::vms_server_plugins::analytics::ironyun;

    switch (instanceIndex)
    {
    case 0: return new object_detection::Plugin();
    case 1: return new facial_recognition::Plugin();
    case 2: return new intrusion_detection::Plugin();
    default: return nullptr;
    }
}
